#!/bin/sh
#$ -S /bin/sh
echo Start Time : 
date
echo g++ -g  -O2	src/SoapNewCov.cpp 	-lz	-L	src/zlib/	-o	bin/SoapNewCov 
# you can add the [ -I /path/.../samtools-1.6/htslib-1.6   -L /path/.../samtools-1.6/htslib-1.6 ] here if can find the htslib
g++ -g  -O2	src/SoapNewCov.cpp 	-lz	-L	src/zlib/	-o	bin/SoapNewCov 
# you can add the [ -I /path/.../samtools-1.6/htslib-1.6   -L /path/.../samtools-1.6/htslib-1.6 ] here if can find the htslib
echo End Time :
date
