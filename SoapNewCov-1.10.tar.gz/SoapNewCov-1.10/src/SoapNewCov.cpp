#ifndef bamCov_H_
#define bamCov_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cstring>
#include <list>
#include <map>
#include <iomanip>
#include "./ALL/comm.h"
#include "./ALL/DataClass.h"
#include <cstdlib>
#include "./gzstream/gzstream.C"
#include "./zlib/zlib.h"
#include <stdio.h>
typedef unsigned long long ubit64_t;
using namespace std;

int  bamCov_help()
{
	cout <<""
		"\n"
		"\tUsage: SoapNewCov  -List  <soap.list> -Dict <Ref.fa.gz>  -OutPut  <out.depth>\n"
		"\n"
		"\t\t-List      <str>     Input soap File List\n"
		"\t\t-Dict      <str>     Input Ref.fa or Ref.dict\n"
		"\t\t-OutPut    <str>     OutPut Depth info Fa file\n"
		"\n"
		"\t\t-Stat                Stat Coverage,MeanDepth & Depth Dis info\n"
		"\t\t-OutWig              Out Depth-GC wig info\n"
		"\t\t-Windows   <int>     Windows size for Depth-GC wig[10000]\n"
		"\n"
		"\t\t-MinHit    <int>     Filter the read bigger Mapping Hit [10]\n"
		"\n"
		"\t\t-help                Show this help [hewm2008 v1.10]\n"
		"\n";
	return 1;
}

int bamCov_help01(int argc, char **argv , In3str1v * paraFA04)
{
	if (argc <=2 ) {bamCov_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "List")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "Dict")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  ==  "Windows")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->Windows=atoi(argv[i]);
		}
		else if (flag  ==  "MinHit")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->MinHit=atoi(argv[i]);
		}
		else if (flag == "OutWig")
		{
			paraFA04->OutWig=true;
		}
		else if (flag == "Stat")
		{
			paraFA04->STAT=false ;
		}
		else if (flag == "help")
		{
			bamCov_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(paraFA04->InStr2)=add_Asuffix(paraFA04->InStr2);

	return 1 ;
}







int Read_chr_info(string path, map <string, pair <int,int32_t> > &  Chr2Int  )
{

	string ext =path.substr(path.rfind('.') ==string::npos ? path.length() : path.rfind('.') + 1);
	int ChrNum=0;

	map <string, pair <int,int32_t> > :: iterator  map_it ;

	if (ext=="dict")
	{

		igzstream IN (path.c_str(),ifstream::in);
		string  line ;
		while(!IN.eof())
		{
			getline(IN,line);
			if (line.length()<=0){ continue ; }
			vector<string> inf;
			split(line,inf," \t");
			if (inf[0] != "@SQ" ){ continue ; }
			inf[2]=replace_all(inf[2],"LN:","");
			inf[1]=replace_all(inf[1],"SN:","");
			int32_t chrLength=atoi(inf[2].c_str());
			pair <int,int32_t > Pare_data = make_pair(ChrNum,chrLength);
			map_it=Chr2Int.find(inf[1]);
			if (map_it!=Chr2Int.end())
			{
				cerr<<"Warning:: ChrName Repeat :" <<inf[1]<<endl;
			}
			else
			{
				Chr2Int.insert(  map <string, pair <int,int32_t> >  :: value_type (inf[1], Pare_data));
			}
			ChrNum++;
		}
		IN.close();

	}
	else
	{
		int AA=path.rfind('/') ==string::npos ? path.length() : path.rfind('/')+1 ;
		string File_Pre =path.substr(0,AA );
		ext =path.substr(AA);
		ext=replace_all(ext,".fasta.gz","");
		ext=replace_all(ext,".fasta","");
		ext=replace_all(ext,".fa.gz","");
		ext=replace_all(ext,".fa","");
		string newDictPath=File_Pre+ext+".dict";

		if ( access(newDictPath.c_str(), 0) == 0 )
		{
			igzstream IN (newDictPath.c_str(),ifstream::in);
			string  line ;
			while(!IN.eof())
			{
				getline(IN,line);
				if (line.length()<=0){ continue ; }
				vector<string> inf;
				split(line,inf," \t");
				if (inf[0] != "@SQ" ){ continue ; }
				inf[2]=replace_all(inf[2],"LN:","");
				inf[1]=replace_all(inf[1],"SN:","");
				int32_t chrLength=atoi(inf[2].c_str());
				pair <int,int32_t > Pare_data = make_pair(ChrNum,chrLength);
				map_it=Chr2Int.find(inf[1]);
				if (map_it!=Chr2Int.end())
				{
					cerr<<"Warning:: ChrName Repeat :" <<inf[1]<<endl;
				}
				else
				{
					Chr2Int.insert(  map <string, pair <int,int32_t> >  :: value_type (inf[1], Pare_data));
				}
				ChrNum++;
			}
			IN.close();



		}
		else
		{
			string newDictPathV2=path+".dict";
			if ( access(newDictPathV2.c_str(), 0) == 0 )
			{
				igzstream IN (newDictPathV2.c_str(),ifstream::in);
				string  line ;
				while(!IN.eof())
				{
					getline(IN,line);
					if (line.length()<=0){ continue ; }
					vector<string> inf;
					split(line,inf," \t");
					if (inf[0] != "@SQ" ){ continue ; }
					inf[2]=replace_all(inf[2],"LN:","");
					inf[1]=replace_all(inf[1],"SN:","");
					int32_t chrLength=atoi(inf[2].c_str());
					pair <int,int32_t > Pare_data = make_pair(ChrNum,chrLength);
					map_it=Chr2Int.find(inf[1]);
					if (map_it!=Chr2Int.end())
					{
						cerr<<"Warning:: ChrName Repeat :" <<inf[1]<<endl;
					}
					else
					{
						Chr2Int.insert(  map <string, pair <int,int32_t> >  :: value_type (inf[1], Pare_data));
					}
					ChrNum++;
				}
				IN.close();
			}
			else
			{
				string newDictPathV3=path+".chrlist";
				if ( access(newDictPathV3.c_str(), 0) == 0 )
				{
				}
				else
				{
					int AA=path.rfind('/') ==string::npos ? path.length() : path.rfind('/')+1 ;
					string File_Pre =path.substr(0,AA );
					ext =path.substr(AA);
					ext=replace_all(ext,".fasta.gz","");
					ext=replace_all(ext,".fasta","");
					ext=replace_all(ext,".fa.gz","");
					ext=replace_all(ext,".fa","");
					newDictPathV3=File_Pre+ext+".chrlist";
				}

				if ( access(newDictPathV3.c_str(), 0) == 0 )
				{
					igzstream IN (newDictPathV3.c_str(),ifstream::in);
					string  line ;
					while(!IN.eof())
					{
						getline(IN,line);
						if (line.length()<=0){ continue ; }
						if (line[0] == '#' ) { continue ; }
						vector<string> inf;
						split(line,inf," \t");
						int32_t chrLength=atoi(inf[1].c_str());
						pair <int,int32_t > Pare_data = make_pair(ChrNum,chrLength);
						map_it=Chr2Int.find(inf[0]);
						if (map_it!=Chr2Int.end())
						{
							cerr<<"Warning:: ChrName Repeat :" <<inf[0]<<endl;
						}
						else
						{
							Chr2Int.insert( map <string, pair <int,int32_t> >  :: value_type (inf[0], Pare_data));
						}
						ChrNum++;
					}
					IN.close();
				}
				else
				{
					gzFile fp;
					kseq_t *seq;
					int l;
					fp = gzopen(path.c_str(), "r");
					seq = kseq_init(fp);
					while ((l = kseq_read(seq)) >= 0)
					{
						int32_t chrLength=(seq->seq.l);
						string chrName=(seq->name.s) ;
						pair <int,int32_t > Pare_data = make_pair(ChrNum,chrLength);
						map_it=Chr2Int.find(chrName);
						if (map_it!=Chr2Int.end())
						{
							cerr<<"Warning:: ChrName Repeat :" <<chrName<<endl;
						}
						else
						{
							Chr2Int.insert(  map <string, pair <int,int32_t> >  :: value_type (chrName, Pare_data));
						}
						ChrNum++;
					}
					kseq_destroy(seq);
					gzclose(fp);
				}
			}
		}
	}

	return ChrNum ;

}

int CheckDict (string RefPath )
{
	string  path=RefPath;
	string ext =path.substr(path.rfind('.') ==string::npos ? path.length() : path.rfind('.') + 1);
	if (ext == "gz" )
	{
		string PrefixO=path.substr(0,path.length()-3);
		path="";path=PrefixO;
	}
	ext =path.substr(path.rfind('.') ==string::npos ? path.length() : path.rfind('.') + 1);
	if (ext =="dict" || ext =="Dict")
	{
		cerr<<"Para [-OutWig]  should be [-Dict Ref.fa] together, Do not with [-Dict Ref.dict]"<<endl;
		return 0 ;
	}
	else if (ext =="fasta" || ext =="fa" || ext =="FA" || ext =="FASTA")
	{
		return 1 ;
	}
	else 
	{
		cerr<<"Para [-OutWig] should with [-Dict Ref.fa] or [-Dict Ref.fasta.gz], suffix be fa or fasta"<<endl;
		return 0 ;
	}
}

int main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	if ((bamCov_help01(argc, argv, paraFA04)==0))
	{
		delete paraFA04 ;
		return 1 ;
	}


	ogzstream  OUT ((paraFA04->InStr2).c_str());
	if((!OUT.good()))
	{
		cerr << "open OUT File error: "<<(paraFA04->InStr2)<<endl;
		delete  paraFA04 ; return  1;
	}

	if (paraFA04->OutWig)
	{
		int AA=CheckDict(paraFA04->InStr3);
		if  (AA==0)
		{
			delete paraFA04 ;
			return 1 ;			 
		}
	}

	map <string, pair <int,int32_t> >   Chr2Int ;
	int NumChr=Read_chr_info(paraFA04->InStr3,Chr2Int);


	if (NumChr<1)
	{
		cerr<<"Chr info Can't Read, some thing wrong\n"<<endl;
		delete  paraFA04 ; return  1;
	}

	cout<<"begin new the memory ...\n";

	unsigned short int **depth = new unsigned short int*[NumChr];//������
	map <string, pair <int,int32_t> > :: iterator Sed_Map_it;


	for ( Sed_Map_it=Chr2Int.begin() ; Sed_Map_it!=Chr2Int.end(); Sed_Map_it++)
	{
		int32_t chrLength=(Sed_Map_it->second).second;
		int i=(Sed_Map_it->second).first;
		depth[i] = new unsigned short int [chrLength]; //������  
		for (int32_t j =0 ; j< chrLength ; j++)
		{
			depth[i][j]=0;
		}
	}

	cout<<"new the memory done"<<endl;

	igzstream LIST ((paraFA04->InStr1).c_str(),ifstream::in); // igzstream
	if (!LIST.good())
	{
		cerr << "open List error: "<<(paraFA04->InStr1)<<endl;
	}

	while(!LIST.eof())
	{
		string  FileA ;
		getline(LIST,FileA);
		if (FileA.length()<=0)  { continue  ; }

		cout <<"Begin Soap :"<<FileA<<endl;
		igzstream SOAP (FileA.c_str(),ifstream::in);
		string readID,seq,seqQi ,ab ,zhefu,chrName ;
		int Hit  ,ReadLen ;   
		int32_t Posi ; 
		while (!SOAP.eof())
		{
			string line ;
			getline(SOAP,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in); 
			isone>>readID>>seq>>seqQi>>Hit;

			if (Hit > (paraFA04->MinHit)  )  {continue ;}
			isone>>ab>>ReadLen>>zhefu>>chrName>>Posi ;
			Sed_Map_it=Chr2Int.find(chrName);
			int ID=(Sed_Map_it->second).first;
			for (int j=0 ; j< ReadLen ; j++)
			{
				int32_t  This=Posi+j;
				depth[ID][This]++;
			}
		}
		SOAP.close();
	}
	LIST.close();


	cout <<"ALL soap done"<<endl;





	if (paraFA04->OutWig)
	{

		string GCDepth=(paraFA04->InStr2).substr(0,(paraFA04->InStr2).length()-3);
		GCDepth=GCDepth+".DepthGC.wig.gz";
		ogzstream  OUTGC (GCDepth.c_str());
		OUTGC<<"##Bigin\tDepth(X)\tGC(%)\n";

		gzFile fp;
		kseq_t *seq;
		int l;
		fp = gzopen((paraFA04->InStr3).c_str(), "r");
		seq = kseq_init(fp);
		int cutOffLen=int((paraFA04->Windows)*0.4);
		while ((l = kseq_read(seq)) >= 0) 
		{
			string chrName=(seq->name.s);
			Sed_Map_it=Chr2Int.find(chrName);
			int NumIntSca=(Sed_Map_it->second).first;
			int  LastDis=((Sed_Map_it->second).second)-(paraFA04->Windows);
			if (LastDis<0){continue ;}
			OUTGC<<"#>"<<(seq->name.s)<<"\tWindowsSite:\t"<<(paraFA04->Windows)<<endl;

			for (int j =0 ; j< LastDis ; j+=(paraFA04->Windows))
			{
				int  Ascii[256] = {0};
				int TotalDepth=0;
				for (int kk=0 ; kk<(paraFA04->Windows) ; kk++)
				{
					int site=j+kk;
					Ascii[seq->seq.s[site]]++;
					TotalDepth+=depth[NumIntSca][site];
				}
				int  N_Aleng= Ascii['N']+Ascii['n'] ;

				int  eff_Acout=(paraFA04->Windows)-N_Aleng ;
				if  (eff_Acout<cutOffLen)
				{
					OUTGC<<(j+1)<<"\tNA\tNA"<<endl;
					continue ;
				}
				int  GC_Aleng=Ascii['C']+Ascii['G'] + Ascii['c']+Ascii['g'] ;
				double MeanDepth=TotalDepth*1.0/eff_Acout;
				double GC_rio=GC_Aleng*100.0/eff_Acout;
				OUTGC<<(j+1)<<"\t"<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<MeanDepth<<"\t"<<GC_rio<<endl;
			}
		}

		OUTGC.close();
		kseq_destroy(seq);
		gzclose(fp);


	}






	if (paraFA04->STAT)
	{
		for ( Sed_Map_it=Chr2Int.begin() ; Sed_Map_it!=Chr2Int.end(); Sed_Map_it++)
		{
			int32_t chrLength=(Sed_Map_it->second).second;
			int i=(Sed_Map_it->second).first;
			OUT<<">"<<Sed_Map_it->first;
			for (int j =0 ; j< chrLength ; j++)
			{
				if (j%50000==0)
				{
					OUT<<endl<<depth[i][j];
				}
				else
				{
					OUT<<" "<<depth[i][j];
				}
			}
			OUT<<endl ;
		}
	}
	else
	{	

		string PrefixO=(paraFA04->InStr2).substr(0,(paraFA04->InStr2).length()-3);
		string StatF=PrefixO+".stat";
		string PLot=PrefixO+".plot";

		ofstream  OUTPLOT (PLot.c_str());
		ofstream  OUTSTAT (StatF.c_str());

		OUTSTAT<<"#ID\tLength\tCoveredBase\tTotalDepth\tcoverage%\tmeanDepth"<<endl;
		OUTPLOT<<"#Depth\tNumber"<<endl;

		map <unsigned short int,ubit64_t> MapDepthSum ;
		map <unsigned short int,ubit64_t> :: iterator Th_mapiT ;
		ubit64_t Sum_chrLen=0;
		ubit64_t Sum_CoverBase=0;
		ubit64_t Sum_Depth=0;

		for ( Sed_Map_it=Chr2Int.begin() ; Sed_Map_it!=Chr2Int.end(); Sed_Map_it++)
		{
			ubit64_t chrLength=(Sed_Map_it->second).second;
			int i=(Sed_Map_it->second).first;
			OUT<<">"<<Sed_Map_it->first;

			map <unsigned short int,ubit64_t> MapDepthChr ;
			map <unsigned short int,ubit64_t> :: iterator mapIt_Depth ;

			for (int j =0 ; j< chrLength ; j++)
			{
				mapIt_Depth=MapDepthChr.find(depth[i][j]);
				if  (mapIt_Depth==MapDepthChr.end())
				{
					MapDepthChr.insert( map <unsigned short int,ubit64_t>  :: value_type (depth[i][j],1));
				}
				else
				{
					(mapIt_Depth->second)++;
				}

				if (j%50000==0)
				{
					OUT<<endl<<depth[i][j];
				}
				else
				{
					OUT<<" "<<depth[i][j];
				}
			}

			OUT<<endl ;
			ubit64_t CovBase=0;
			ubit64_t TotalDepth=0;
			for (mapIt_Depth=MapDepthChr.begin(); mapIt_Depth!=MapDepthChr.end(); mapIt_Depth++)
			{
				if ((mapIt_Depth->first)!=0)
				{
					CovBase+=mapIt_Depth->second;
				}
				Th_mapiT=MapDepthSum.find(mapIt_Depth->first);
				TotalDepth+=(mapIt_Depth->second)*(mapIt_Depth->first);
				if (Th_mapiT==MapDepthSum.end())
				{					
					MapDepthSum.insert( map <unsigned short int,ubit64_t>  :: value_type (mapIt_Depth->first,mapIt_Depth->second));
				}
				else
				{
					(Th_mapiT->second)+=(mapIt_Depth->second);
				}
			}

			double Coverage=CovBase*100.0/((Sed_Map_it->second).second);
			double MeanDepth=TotalDepth*1.0/((Sed_Map_it->second).second);
			Sum_chrLen+=((Sed_Map_it->second).second);
			Sum_CoverBase+=CovBase ;
			Sum_Depth+=TotalDepth;
			OUTSTAT<<Sed_Map_it->first<<"\t"<<(Sed_Map_it->second).second<<"\t"<<CovBase<<"\t"<<TotalDepth<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"\t"<<Coverage<<"\t"<<MeanDepth<<endl;

		}

		double Coverage=Sum_CoverBase*100.0/Sum_chrLen ;
		double MeanDepth=Sum_Depth*1.0/Sum_chrLen ;

		OUTSTAT<<"#Genome\t"<<Sum_chrLen<<"\t"<<Sum_CoverBase<<"\t"<<Sum_Depth<<setiosflags(ios::fixed)<<setiosflags(ios::right)<<setprecision(2)<<"\t"<<Coverage<<"\t"<<MeanDepth<<endl;

		for (Th_mapiT=MapDepthSum.begin(); Th_mapiT!=MapDepthSum.end() ;Th_mapiT++)
		{
			OUTPLOT<<Th_mapiT->first<<"\t"<<Th_mapiT->second<<endl;
		}
		OUTSTAT.close();
		OUTPLOT.close();
	}


	OUT.close();

	//�ͷſ��ٵ���Դ  
	for(int i = 0; i <NumChr; i++)
	{
		delete[] depth[i];  
	}
	delete[] depth;  


	delete paraFA04 ;
	return 0;
}
#endif // bamCov_H_  //
///////// swimming in the sky and flying in the sea ////////////





